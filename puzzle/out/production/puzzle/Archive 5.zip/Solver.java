import edu.princeton.cs.algs4.Stack;
import edu.princeton.cs.algs4.MinPQ;


public class Solver {

    private Stack<Board> path;
    private MinPQ<SearchNode> minPQ, twinMinPQ;
    private boolean isSolvable;
    private int moves;

    public Solver(Board initial) {
        if (initial == null) throw new NullPointerException();

        path = new Stack<Board>();

        SearchNode node = new SearchNode(initial, 0, null);
        minPQ = new MinPQ<>();
        minPQ.insert(node);

        SearchNode twinNode = new SearchNode(initial, 0, null);
        twinMinPQ = new MinPQ<>();
        twinMinPQ.insert(twinNode);

        int i = 0;

        while( i < 1000 ) {
            i++;

            // Delete a minimal priority node from the MinPQ
            node = minPQ.delMin();
            twinNode = twinMinPQ.delMin();

            if (node.board.isGoal() || twinNode.board.isGoal())
                break;

            // Fetch neighbours, but drop previous.
            Iterable<Board> neighbours = node.board.neighbors();
            for (Board b :neighbours) {
                if (!(node.prev != null && b.equals(node.prev.board))) {
                    minPQ.insert(new SearchNode(b, moves, node));
                }
            }

            // Fetch neighbours, but drop previous.
            neighbours = twinNode.board.neighbors();
            for (Board b :neighbours) {
                if (!(twinNode.prev != null && b.equals(twinNode.prev.board))) {
                    twinMinPQ.insert(new SearchNode(b, moves, twinNode));
                }
            }
        }

        if (node.board.isGoal()) {
            isSolvable = true;
            path.push(node.board);
            while (node.prev != null) {
                moves++;
                node = node.prev;
                path.push(node.board);
            }
        }
        else {
            isSolvable = false;
            moves = -1;
        }
    }

    public boolean isSolvable() {
        return isSolvable;
    }

    public int moves() {
        return moves;
    }

    public Iterable<Board> solution() {
        return path;
    }


    private class SearchNode implements Comparable<SearchNode> {
        private Board board;
        private SearchNode prev;
        private int moves;
        private int priority;

        public SearchNode(Board board, int moves, SearchNode prev) {
            this.prev = prev;
            this.board = board;
            this.moves = moves;
            this.priority = -1;
        }

        public int priority() {
            if (priority != -1)
                return priority;

            priority = moves + board.manhattan();
            return priority;
        }

        @Override
        public int compareTo(SearchNode that) {
            return this.priority() - that.priority();
        }
    }




    public static void main(String[] args) {

    }
}